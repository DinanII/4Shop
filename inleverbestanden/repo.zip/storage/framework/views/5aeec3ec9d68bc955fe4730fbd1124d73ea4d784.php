

<?php $__env->startSection('content'); ?>

	<?php if(!$order->payed): ?>
		<div class="alert alert-info">
			<h5 class="alert-heading">Nog niet betaald</h5>
			<p>Let op: deze bestelling is nog niet betaald. U kunt de bestelling ook nog annuleren.</p>
			<hr>
			<p>
				<a href="<?php echo e(route('ideal.pay', $order)); ?>" class="alert-link">Nu betalen &gt;</a>
				<a href="<?php echo e(route('order.cancel', [$order, $order->slug])); ?>" class="alert-link ml-3">Annuleren &gt;</a>
			</p>
		</div>
	<?php endif; ?>

	<div class="d-flex justify-content-between mt-5">
		<div>
			<h5><em>Bestelling #<?php echo e($order->slug); ?></em></h5>
			<p><?php echo e($order->name); ?> (<?php echo e($order->speltak); ?>)</p>
		</div>
		<div>
			<?php if($order->payed): ?>
				<span class="badge badge-success">Betaald</span>
			<?php else: ?>
				<span class="badge badge-warning">Niet betaald</span>
			<?php endif; ?>
		</div>
	</div>
	

	<table class="table mb-5">
		<?php $total = 0; ?>
		<?php $__currentLoopData = $order->rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($rule->product); ?></td>
				<td><?php echo e($rule->type); ?> <?php echo e($rule->size); ?></td>
				<td class="text-right">&euro;<?php echo e($rule->price); ?></td>
				<?php $total += $rule->price; ?>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td colspan="2"><strong>Totaal</strong></td>
			<td class="text-right"><strong>&euro;<?php echo e(number_format($total, 2)); ?></strong></td>
		</tr>
	</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\4Shop\resources\views/orders/show.blade.php ENDPATH**/ ?>