<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>4Shop DINAN</title>

    <!-- Styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/narrow-jumbotron.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    
    <script src="/js/app.js"></script>
</head>
<body>
    <div class="container">
      <header class="header d-flex justify-content-between align-items-center">
        <h3 class="text-muted"><a href="<?php echo e(route('home')); ?>" class="no-link">4Shop</a></h3>
        <a href="<?php echo e(route('cart')); ?>"><img class="cart" src="<?php echo e(url('img/cart.png')); ?>" alt=""></a>
      </header>

      <main role="main">
        <?php if(session('status')): ?>
            <div class="alert alert-<?php echo e(session('status')[0]); ?>">
                <?php echo session('status')[1]; ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
      </main>

      <footer class="footer">
        <p><strong>Mail bij vragen: <a href="mailto:winkelbeheer@4shop.nl">winkelbeheer@4shop.nl</a></strong> &middot; 4S BV, Kerklaan 22 4942AR Raamsdonksveer, KvK: 41100325, tel: 0162-769096.</p>
      </footer>

    </div>
</body>
</html>
<?php /**PATH C:\laravel\4Shop\resources\views/layouts/app.blade.php ENDPATH**/ ?>