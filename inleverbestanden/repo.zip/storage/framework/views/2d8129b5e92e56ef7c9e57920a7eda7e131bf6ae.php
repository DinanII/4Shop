

<?php $__env->startSection('content'); ?>
	
	<div class="d-flex justify-content-between align-items-center my-4">
		<h4>Bestellingen</h4>
		<div>
			<a href="<?php echo e(route('admin.orders.factory')); ?>" target="_blank">Bekijk overzicht voor producent &gt;</a><br />
			<a href="<?php echo e(route('admin.orders.mail')); ?>">Verstuur mails over ophalen &gt;</a><br />
			<a href="<?php echo e(route('admin.orders.packing')); ?>" target="_blank">Print pakbonnen &gt;</a>
		</div>
		
	</div>
	
	<table class="table table-striped table-hover">
		<tr>
			<th>#</th>
			<th>Naam</th>
			<th>Speltak</th>
			<th>Bedrag</th>
			<th>Betaling</th>
			<th>Levering</th>
		</tr>
		<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td>
					<a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"><?php echo e($order->slug); ?></a>
				</td>
				<td><?php echo e($order->name); ?></td>
				<td><?php echo e(ucfirst($order->speltak)); ?></td>
				<td>&euro;<?php echo e(number_format($order->amount, 2)); ?></td>
				<td>
					<?php echo $order->payed ? '<span class="badge badge-success">betaald</span>' : '<span class="badge badge-warning">niet betaald</span>'; ?>

				</td>
				<td>
					<?php if($order->delivered): ?>
						<a href="<?php echo e(route('admin.orders.deliverytoggle', $order)); ?>"><span class="badge badge-success">Geleverd</span></a>
					<?php else: ?>
						<a href="<?php echo e(route('admin.orders.deliverytoggle', $order)); ?>"><span class="badge badge-warning">niet geleverd</span></a>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\4Shop\resources\views/admin/orders.blade.php ENDPATH**/ ?>