<table class="table">

	<?php $total = 0; ?>
	<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($rule->product->title); ?></td>
			<td><?php echo e($rule->type->title); ?>

                <?php if($rule->size): ?>
                    <?php echo e($rule->size->title); ?>

                <?php endif; ?>
            </td>
			<td class="text-right">&euro;<?php echo e($rule->product->price); ?></td>
			<?php if($remove): ?>
				<td class="text-right"><a href="<?php echo e(route('cart.remove', $key)); ?>">X</a></td>
			<?php endif; ?>
			<?php $total += $rule->product->price; ?>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td colspan="2"><strong>Totaal</strong></td>
		<td class="text-right"><strong>&euro;<?php echo e(number_format($total, 2)); ?></strong></td>
		<?php if($remove): ?>
			<td></td>
		<?php endif; ?>
	</tr>
</table>
<?php /**PATH C:\laravel\4Shop\resources\views/orders/partial_cart.blade.php ENDPATH**/ ?>