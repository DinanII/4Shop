

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center my-5"> 

	<form action="<?php echo e(route('admin.products.types.store', $product)); ?>" method="POST" style="min-width: 320px;">
		
		<h4><?php echo e($product->title); ?> &gt; Nieuwe type</h4>

		<div class="form-group">
			<label for="title">Titel</label>
			<input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder="Dames">
		</div>
		<div class="form-group">
			<label for="description">Omschrijving van type t.b.v. fabrikant</label>
			<input type="text" id="description" name="description" class="form-control" value="<?php echo e(old('description')); ?>" placeholder="Basic hoody full-zip Ladies (grijs, logo voor en achter)">
		</div>
		<div class="form-group">
			<label for="sizes">Maten (voer alle maten in, gescheiden door een komma)</label>
			<textarea name="sizes" id="sizes" cols="30" rows="5" class="form-control" placeholder="XS,S,M,..."></textarea>
		</div>

		<button type="submit" class="form-control btn btn-primary my-2">Opslaan</button>
		<?php echo e(csrf_field()); ?>

	</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\4Shop\resources\views/admin/products/types_create.blade.php ENDPATH**/ ?>