

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between my-5">
	<div>
		<h4><?php echo e($product->title); ?></h4>
		<p class="lead">&euro;<?php echo e(number_format($product->price, 2)); ?></p>
		<p>
			<?php if($product->active): ?>
				<span class="badge badge-success">Zichtbaar</span>
			<?php else: ?>
				<span class="badge badge-light">Onzichtbaar</span>
			<?php endif; ?>
			<?php if($product->leiding): ?>
				<span class="badge badge-info">Leiding</span>
			<?php else: ?>
				<span class="badge badge-primary">Leden</span>
			<?php endif; ?>
		</p>
		<p><?php echo e($product->description); ?></p>
		<p>
			<a href="<?php echo e(route('admin.products.index')); ?>">Terug naar overzicht &gt;</a><br />
			<a href="<?php echo e(route('admin.products.edit', $product)); ?>">Product-info aanpassen &gt;</a>
		</p>
	</div>
	<div class="ml-5 w-50 text-right">
		<img src="<?php echo e(url($product->image ?? 'img/placeholder.jpg')); ?>" alt="<?php echo e($product->title); ?>" class="rounded mw-100">
	</div>
</div>
<hr class="my-5">

<table class="table table-striped table-hover">
	<tr>
		<th>Type</th>
		<th>Maten</th>
		<th>Fabrikant</th>
		<th></th>
	</tr>
	<?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($type->title); ?></td>
			<td><?php echo e($type->sizes->implode('title', ', ')); ?></td>
			<td><small><em><?php echo e($type->description); ?></em></small></td>
			<td>
				<form action="<?php echo e(route('admin.products.types.delete', [$product, $type])); ?>" method="POST" class="m-0">
					<button type="submit" class="btn btn-link m-0 p-0">Verwijderen</button>
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('DELETE')); ?>

				</form>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td colspan="4">
			<a href="<?php echo e(route('admin.products.types.create', $product)); ?>">Nieuw type toevoegen &gt;</a>
		</td>
	</tr>
</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\4Shop\resources\views/admin/products/types.blade.php ENDPATH**/ ?>