

<?php $__env->startSection('content'); ?>

	<h5><em>Winkelwagentje</em></h5>
	<?php echo $__env->make('orders.partial_cart', ['remove' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="d-flex justify-content-end my-4">
		<a href="<?php echo e(route('shop')); ?>" class="btn btn-primary mr-3">Verder winkelen &gt;</a>
		<a href="<?php echo e(route('order')); ?>" class="btn btn-success">Bestellen &gt;</a>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\4Shop\resources\views/orders/cart.blade.php ENDPATH**/ ?>