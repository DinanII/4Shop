

<?php $__env->startSection('content'); ?>
    <div class="categories">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <ul><li><a href="<?php echo e(route('tocategory', ['category' => $category->id])); ?>"><?php echo e($category->name); ?></a></li></ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
        <a class="product-row no-link" href="<?php echo e(route('products.show', $product)); ?>">
            <img src="<?php echo e(url($product->image ?? 'img/placeholder.jpg')); ?>" alt="<?php echo e($product->title); ?>" class="rounded">
            <div class="product-body">
                <div>
                    <h5 class="product-title"><span><?php echo e($product->title); ?></span><em>&euro;<?php echo e($product->price); ?></em></h5>
                    <?php if (! (empty($product->description))): ?>
                        <p><?php echo e($product->description); ?></p>
                    <?php endif; ?>
                </div>
                <div class="sale">
                <?php if( $product->discount > 0): ?>
                    <p>
                        <span class="important">Nu <b><?php echo e($product->discount); ?>%</b> korting</span> <!-- Orginele prijs: <?php echo e($product->getOriginal('price')); ?> -->
                    </p>
                    <p>
                        Orginele prijs: <?php echo e($product->getRawOriginal('price')); ?> 
                    </p>
                <?php endif; ?>
                </div>
                <button class="btn btn-primary">Meer info &amp; bestellen</button>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\4Shop\resources\views/products/sorted.blade.php ENDPATH**/ ?>