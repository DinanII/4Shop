

<?php $__env->startSection('content'); ?>
	

	<h4>Mails versturen</h4>
	<p>Onderstaande bestellers ontvangen een mail dat hun bestelling klaar ligt. De tekst onder het kopje <em>ophalen</em> moet je hieronder zelf nog invullen.</p>

	<form action="<?php echo e(route('admin.orders.mail.send')); ?>" method="POST">
		<p class="m-0"><strong>Ophalen</strong></p>
		<textarea name="pickup" id="" cols="30" rows="5" class="form-control">De bestelling is op te halen op het Scoutinggebouw, bij voorkeur aanstaande zaterdag om 12.00u. Daarna iedere zaterdag voor of na de opkomst. Vraag er even naar bij je speltakleiding!</textarea>
		<button type="submit" class="btn btn-success mt-3">Verstuur e-mails</button>
		<?php echo e(csrf_field()); ?>

	</form>

	<table class="table table-striped table-hover mt-5">
		<tr>
			<th>#</th>
			<th>Naam</th>
			<th>Speltak</th>
			<th>Bedrag</th>
			<th>Betaling</th>
		</tr>
		<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td>
					<a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"><?php echo e($order->slug); ?></a>
				</td>
				<td><?php echo e($order->name); ?></td>
				<td><?php echo e(ucfirst($order->speltak)); ?></td>
				<td>&euro;<?php echo e(number_format($order->amount, 2)); ?></td>
				<td>
					<?php echo $order->payed ? '<span class="badge badge-success">betaald</span>' : '<span class="badge badge-warning">niet betaald</span>'; ?>

				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\wdv-laravel_oefenopdrachten\4Shop\resources\views/admin/mail.blade.php ENDPATH**/ ?>