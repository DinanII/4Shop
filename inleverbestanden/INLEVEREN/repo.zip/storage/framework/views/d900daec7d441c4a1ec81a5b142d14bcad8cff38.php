

<?php $__env->startSection('content'); ?>
	

    <div class="flex_container">
        <div class="form-container">
            <form action="<?php echo e(route('admin.categories.update', $category)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h4>Categorie aanpassen</h4>
                <div class="form-group">
                    <label for="name">Naam</label>
                    <input type="text" name="name" value="<?php echo e($category->name); ?>">
                </div>
                </div>
                <div class="form-group">
                    <input type="radio" id="active" name="active" value="1">
                    <label for="active">Actief</label>

                    <input type="radio" id="inactive" name="active" value="0">
                    <label for="inactive">Inactief</label>
                </div>

                <div class="form-group">
                    <label for="submit">Aanpassen</label>
                    <input type="submit" value="Aanpassen">
                </div>

            </form>
            <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="post">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="delete">Verwijder</label>
                    <input type="submit" value="delete">
                </div>
            </form>
        </div>


        
        <div class="products">
            <h4>Producten</h4>
            <ul>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product->category_id == $category->id): ?>
                        <li><?php echo e($product->title); ?></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\wdv-laravel_oefenopdrachten\4Shop\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>