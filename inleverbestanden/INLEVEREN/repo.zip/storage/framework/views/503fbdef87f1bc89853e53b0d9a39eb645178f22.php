

<?php $__env->startSection('content'); ?>
	
	<div class="d-flex justify-content-between align-items-center my-4">
		<h4>Accounts</h4>
		<div>
			<a href="<?php echo e(route('admin.users.create')); ?>">Nieuwe gebruiker toevoegen</a>
		</div>
	</div>

	<table class="table table-striped table-hover">
		<tr>
			<th>Naam</th>
			<th>E-mail</th>
			<th>&nbsp;</th>
		</tr>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($user->name); ?></td>
				<td><?php echo e($user->email); ?></td>
				<td>
					<a href="<?php echo e(route('admin.users.edit', $user->id)); ?>">Aanpassen</a>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\wdv-laravel_oefenopdrachten\4Shop\resources\views/admin/users/index.blade.php ENDPATH**/ ?>