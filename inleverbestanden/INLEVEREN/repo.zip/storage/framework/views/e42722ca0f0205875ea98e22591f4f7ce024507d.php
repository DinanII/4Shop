

<?php $__env->startSection('content'); ?>
	
	<div class="d-flex justify-content-between align-items-center my-4">
        <div class="edit">
            <h4>Categorie toevoegen</h4>
            <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST" style="min-width: 320px;" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Naam</label>
                    <input type="text" name="name">
                </div>
                <div class="form-group">
                    <input type="radio" id="active" name="active" value="1">
                    <label for="active">Actief</label><br>
                    <input type="radio" id="inactive" name="active" value="0">
                    <label for="inactive">Inactive</label><br>
                </div>

                <div class="form-group">
                    <!-- <label for="submit">Toevoegen</label> -->
                    <input type="submit" value="Toevoegen">
                </div>
            </form>

        </div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\wdv-laravel_oefenopdrachten\4Shop\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>